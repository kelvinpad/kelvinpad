CREATE DATABASE db_perpuspi;
USE db_perpuspi;

CREATE TABLE penulis (
	id_penulis int not null primary key auto_increment,
    nama_penulis VARCHAR (255) NOT NULL
    );

CREATE TABLE buku(
	isbn VARCHAR (255) NOT NULL PRIMARY KEY,
	judul VARCHAR (255) NOT NULL, 
    tahun YEAR NOT NULL ,
    id_penulis INT NOT NULL,
    FOREIGN KEY (id_penulis) REFERENCES penulis(id_penulis)
    );

INSERT INTO penulis(nama_penulis)
VALUES 
('Pramoedya Ananta Toer'),
('Ahmad Fuadi'),
('Dee Lestari'),
('Hamka'),
(' Achdiat K. Mihardja, R.J. Maguire'),
('Fiersa Besari'),
('Pidi Baiq'),
('Koentjaraningrat'),
('Max Weber'),
('Raditya Dika'),
('Donny Dhirgantoro'),
('Habiburrahman El-Shirazy'),
('Tere Liye'),
('Annisa Ihsani')
;

INSERT INTO buku ( isbn, tahun,judul, id_penulis )
	VALUES 
    ('9789799731234', 2005,'Bumi Manusia', 1),
	('9780140256338', 2000,'Anak Semua Bangsa', 1),
    ('9789792248616', 2009,'Negri 5 Negara',2),
    ('9789791227780', 2009,'Perahu Kertas',3),
    ('9789679370256', 1987,'Tenggelamnya Kapal Van Der Wijck', 4),
    ('9780702207655', 1972,'Atheis',5),
    ('9789797945350', 2017,'Konsfirasi Alam Semesta',6),
    ('9789797945497', 2017,'Catatan Juang',6),
    ('9786027870413', 2014,'Dilan: Dia Adalah Dilanku Tahun 1990',7),
    ('9794280631', 1988,'Manusia dan Kebudayaan di Indonesiav',8),
    ('9786027724020', 2012,'Teori Dasar Analisis Kebudayaan',9),
    ('9789797809157', 2018,'Ubur-ubur Lembur',10),
    ('9786028066648', 2010,'Marmut Merah Jambu',10),
    ('9789797591519', 2005,'5 cm',11),
    ('9832672368',2007,'Ayat-Ayat Cinta',12),
    ('9786028997959', 2014,'Api Tauhid',12),
    ('9786020324784', 2016,'Hujan',13),
    ('9793858133', 2009,'Rembulan Tenggelam Di Wajahmu',13),
    ('9786020326313', 2016,'A untuk Amanda',14)
    ;

CREATE TABLE rating_buku (
	isbn VARCHAR (255) NOT NULL,
    nama_pengulas_buku VARCHAR (255),
    bintang_buku INT ,
    komentar_buku VARCHAR (255),
    FOREIGN KEY (isbn) REFERENCES buku(isbn)
    );

CREATE TABLE rating_penulis (
	id_penulis INT NOT NULL,
    nama_pengulas_penulis VARCHAR (255),
    bintang_penulis INT ,
    komentar_penulis VARCHAR (255),
    FOREIGN KEY (id_penulis) REFERENCES penulis(id_penulis)
    );
