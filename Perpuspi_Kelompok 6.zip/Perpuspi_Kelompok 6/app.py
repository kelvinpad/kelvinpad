from flask import Flask, render_template, \
     request, redirect, url_for, jsonify
from mysqlx import SqlResult
import pymysql.cursors

application = Flask(__name__)

conn = cursor = None

#fungsi koneksi database
def openDb():
   global conn, cursor
   conn = pymysql.connect(
        host='localhost',
        user='root', 
        password = "@14Mf0rsql",
        db='db_perpuspi',
        )
   cursor = conn.cursor()	


#fungsi untuk menutup koneksi
def closeDb():
   global conn, cursor
   cursor.close()
   conn.close()


#fungsi Home
@application.route('/')
def home():   
   return render_template('home.html')


#fungsi Cari
@application.route('/cari_buku', methods=['GET','POST'])
def cari_buku():
    if request.method == "POST":
        cari = request.form['cari']

        openDb()
        sql = "SELECT buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun from buku JOIN penulis on buku.id_penulis = penulis.id_penulis WHERE buku.isbn LIKE %s OR buku.judul LIKE %s OR penulis.nama_penulis LIKE %s OR buku.tahun LIKE %s"
        val = (cari, cari, cari, cari)
        cursor.execute(sql, val)
        conn.commit()
        data = cursor.fetchall()

        if len(data) == 0 and cari == 'all': 
            cursor.execute("select buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun, avg(rating_buku.bintang_buku) as rating from buku inner join penulis on penulis.id_penulis = buku.id_penulis left join rating_buku on buku.isbn = rating_buku.isbn group by buku.isbn;")
            conn.commit()
            data = cursor.fetchall()
        return render_template('cari_buku.html', data=data)
    return render_template('cari_buku.html')


#Fungsi Daftar Buku
@application.route('/daftar_buku')
def daftar_buku():   
   openDb()
   container = []
   sql = "select buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun, avg(rating_buku.bintang_buku) as rating from buku inner join penulis on penulis.id_penulis = buku.id_penulis left join rating_buku on buku.isbn = rating_buku.isbn group by buku.isbn;"
   cursor.execute(sql)
   results = cursor.fetchall()
   for data in results:
      container.append(data)
   closeDb()
   return render_template('daftar_buku.html', container=container,)


#Fungsi Daftar Penulis
@application.route('/daftar_penulis')
def daftar_penulis():   
   openDb()
   container = []
   sql = "select penulis.id_penulis, penulis.nama_penulis, avg(rating_penulis.bintang_penulis) from penulis left join rating_penulis on penulis.id_penulis = rating_penulis.id_penulis group by penulis.nama_penulis;"
   cursor.execute(sql)
   results = cursor.fetchall()
   for data in results:
      container.append(data)
   closeDb()
   return render_template('daftar_penulis.html', container=container,)

#fungsi view edit() untuk form edit
@application.route('/beri_ulasan_buku/<isbn>', methods=['GET','POST'])
def beri_ulasan_buku(isbn):
   openDb()
   cursor.execute('SELECT isbn FROM buku WHERE isbn=%s', (isbn))
   data = cursor.fetchone()
   if request.method == 'POST':
      isbn = request.form['isbn']
      pengulas_buku = request.form['pengulas_buku']
      bintang_buku = request.form['bintang_buku']
      komentar_buku = request.form['komentar_buku']
      sql = "INSERT INTO rating_buku (isbn, nama_pengulas_buku, bintang_buku, komentar_buku) VALUES (%s, %s, %s, %s)"
      val = (isbn, pengulas_buku, bintang_buku, komentar_buku)
      cursor.execute(sql, val)
      conn.commit()
      closeDb()
      return redirect(url_for('daftar_buku'))
   else:
      closeDb()
      return render_template('beri_ulasan_buku.html', data=data)

@application.route('/lihat_ulasan_buku/<isbn>', methods=['GET', 'POST'])
def lihat_ulasan_buku(isbn):
   openDb()
   container = []
   sql ="select rating_buku.nama_pengulas_buku, rating_buku.bintang_buku, rating_buku.komentar_buku from rating_buku where rating_buku.isbn =%s;"
   cursor.execute(sql, (isbn))
   results = cursor.fetchall()
   for data in results:
      container.append(data)
   closeDb()
   return render_template('lihat_ulasan_buku.html', container=container,)

@application.route('/beri_ulasan_penulis/<id_penulis>', methods=['GET','POST'])
def beri_ulasan_penulis(id_penulis):
   openDb()
   cursor.execute('SELECT id_penulis FROM penulis WHERE id_penulis=%s', (id_penulis))
   data = cursor.fetchone()
   if request.method == 'POST':
      id_penulis = request.form['id_penulis']
      pengulas_penulis = request.form['pengulas_penulis']
      bintang_penulis = request.form['bintang_penulis']
      komentar_penulis = request.form['komentar_penulis']
      sql = "INSERT INTO rating_penulis (id_penulis, nama_pengulas_penulis, bintang_penulis, komentar_penulis) VALUES (%s, %s, %s, %s)"
      val = (id_penulis, pengulas_penulis, bintang_penulis, komentar_penulis)
      cursor.execute(sql, val)
      conn.commit()
      closeDb()
      return redirect(url_for('daftar_penulis'))
   else:
      closeDb()
      return render_template('beri_ulasan_penulis.html', data=data)

@application.route('/lihat_ulasan_penulis/<id_penulis>', methods=['GET', 'POST'])
def lihat_ulasan_penulis(id_penulis):
   openDb()
   container = []
   sql ="select rating_penulis.nama_pengulas_penulis, rating_penulis.bintang_penulis, rating_penulis.komentar_penulis from penulis inner join rating_penulis on penulis.id_penulis = rating_penulis.id_penulis where penulis.id_penulis =%s"
   cursor.execute(sql, (id_penulis))
   results = cursor.fetchall()
   for data in results:
      container.append(data)
   closeDb()
   return render_template('lihat_ulasan_penulis.html', container=container,)

if __name__ == '__main__':
   application.run(debug=True)