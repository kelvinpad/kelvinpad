from flask import Flask, render_template, \
     request, redirect, url_for
from mysqlx import SqlResult
import pymysql.cursors

app = Flask(__name__)

conn = cursor = None

#fungsi koneksi database
def openDb():
   global conn, cursor
   conn = pymysql.connect(
        host='localhost',
        user='root', 
        password = "@14Mf0rsql",
        db='db_perpuspi',
        )
   cursor = conn.cursor()	

#fungsi untuk menutup koneksi
def closeDb():
   global conn, cursor
   cursor.close()
   conn.close()

#fungsi Home_admin
@app.route('/home_admin')
def home_admin():   
   return render_template('home_admin.html')

#fungsi view tambah_buku() untuk membuat form tambah_buku
@app.route('/home_admin/tambah_buku', methods=['GET','POST'])
def tambah_buku():
   if request.method == 'POST':
      isbn = request.form['isbn']
      judul = request.form['judul']
      id_penulis = request.form['id_penulis']
      tahun = request.form['tahun']
      openDb()
      sql = "INSERT INTO buku (isbn, judul, id_penulis, tahun) VALUES (%s, %s, %s, %s)"
      val = (isbn, judul, id_penulis, tahun)
      cursor.execute(sql, val)
      conn.commit()
      closeDb()
      return redirect(url_for('tambah_buku'))
   else:
      return render_template('tambah_buku.html')

#fungsi view tambah_penulis() untuk membuat form tambah_penulis
@app.route('/home_admin/tambah_penulis', methods=['GET','POST'])
def tambah_penulis():
   if request.method == 'POST':
      nama_penulis = request.form['nama_penulis']
      openDb()
      sql = "INSERT INTO penulis (nama_penulis) VALUES (%s)"
      val = (nama_penulis)
      cursor.execute(sql, val)
      conn.commit()
      closeDb()
      return redirect(url_for('home_admin'))
   else:
      return render_template('tambah_penulis.html')

#fungsi untuk menghapus data
@app.route('/home_admin/hapus_buku/<isbn>', methods=['GET','POST'])
def hapus_buku(isbn):
   openDb()
   cursor.execute('DELETE FROM buku WHERE isbn=%s', (isbn))
   conn.commit()
   closeDb()
   return redirect(url_for('daftar_buku_admin'))

#fungsi view edit_buku() untuk form edit_buku
@app.route('/home_admin/edit_buku/<isbn>', methods=['GET','POST'])
def edit_buku(isbn):
   openDb()
   cursor.execute('SELECT * FROM buku WHERE isbn=%s', (isbn))
   data = cursor.fetchone()
   if request.method == 'POST':
      isbn = request.form['isbn']
      judul = request.form['judul']
      id_penulis = request.form['id_penulis']
      tahun= request.form['tahun']
      sql = "UPDATE buku SET judul = %s, id_penulis = %s, tahun = %s WHERE isbn = %s"
      val = (judul, id_penulis, tahun, isbn)
      cursor.execute(sql, val)
      conn.commit()
      closeDb()
      return redirect(url_for('home_admin'))
   else:
      closeDb()
      return render_template('edit_buku.html', data=data)

#fungsi view daftar() untuk menampilkan data dari database
@app.route('/home_admin/daftar_buku_admin')
def daftar_buku_admin():   
   openDb()
   container = []
   sql = "select buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun, avg(rating_buku.bintang_buku) as rating from buku inner join penulis on penulis.id_penulis = buku.id_penulis left join rating_buku on buku.isbn = rating_buku.isbn group by buku.isbn;"
   cursor.execute(sql)
   results = cursor.fetchall()
   for data in results:
      container.append(data)
   closeDb()
   return render_template('daftar_buku_admin.html', container=container,)

@app.route('/home_admin/cari_buku_admin', methods=['GET','POST'])
def cari_buku_admin():
    if request.method == "POST":
        cari = request.form['cari']

        openDb()
        sql = "SELECT buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun from buku JOIN penulis on buku.id_penulis = penulis.id_penulis WHERE buku.isbn LIKE %s OR buku.judul LIKE %s OR penulis.nama_penulis LIKE %s OR buku.tahun LIKE %s"
        val = (cari, cari, cari, cari)
        cursor.execute(sql, val)
        conn.commit()
        data = cursor.fetchall()

        if len(data) == 0 and cari == 'all': 
            cursor.execute("select buku.isbn, buku.judul, penulis.nama_penulis, buku.tahun from buku inner join penulis on penulis.id_penulis = buku.id_penulis group by buku.isbn;")
            conn.commit()
            data = cursor.fetchall()
        return render_template('cari_buku_admin.html', data=data)
    return render_template('cari_buku_admin.html')

if __name__ == '__main__':
   app.run(debug=True)